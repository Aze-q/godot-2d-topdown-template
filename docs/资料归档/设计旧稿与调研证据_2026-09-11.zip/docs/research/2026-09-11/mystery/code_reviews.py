import json, pathlib, datetime, collections, csv
root=pathlib.Path(__file__).parent
# Hand-coded after reading every full review. No automatic keyword classification.
codes={
 'O':'明确抱怨信息过隐、机制难发现、没有方向或需查攻略',
 'R':'明确抱怨导航、重复回访、重跑、检查点或捷径',
 'C':'明确抱怨战斗、动作操作手感或招式执行',
 'A':'明确抱怨无障碍、镜头不适或改键',
 'E':'类型预期/玩法配比不匹配，或能力锁取代想象中的谜题',
 'L':'叙事/谜团兑现或后期秘密负体验',
 'D':'难度或惩罚造成挫折（未必战斗）',
 'P':'明确肯定谜题、发现、知识进展、线索或回访变化',
 'V':'明确肯定画面、音乐、氛围',
 'B':'明确肯定战斗/Boss/操作',
 'F':'明确肯定新鲜感或品类体验',
 'Q':'具体内容解锁时间建议',
 'N':'缺乏可定位机制的实质理由，仅总体态度/评分/比喻',
}
manual={
 'tunic-negative':[
 ('O,V,B','肯定战斗/Boss和音画；谜题令其迷失。'),
 ('O','核心装备和操作机制可错过，破坏可玩性。'),
 ('C,E,P','以探索解谜游戏预期购买；认为前段战斗乏味，后段知识谜题有乐趣。文中60%等均为个人估计。'),
 ('R,L,B','战斗尚可；导航没有改善；真结局兑现令人失望。'),
 ('L,P','肯定说明书创意，但认为其谜团质量不及期待。'),
 ('E,L,B','享受类魂部分，却不喜欢取得好结局的谜题；感到战斗结局遭惩罚。'),
 ('O,C','细节太隐蔽而需Google；战斗失衡；认可背景故事。'),
 ('R,L,O,C','回访乏味、后期谜题繁琐难懂，操作缺少响应。'),
 ('C,L,P,V','肯定说明书和特定秘密创意；认为故事线索未展开、格挡和Boss有问题。'),
 ('O,V','无法读懂文字，认为晦涩；音乐好。'),
 ('C,O,D','战斗与移动生硬、Boss镜头差，信息过隐。'),
 ('R,O,C,L','等距遮挡令盲探受挫；操作导致死亡；真结局谜题过隐。'),
 ('N','搁置后不愿再玩，但没有给出具体机制原因。'),
 ('A,R,O,L','地图缺失及反复回访；Boss旋转背景不适；末段长序列输入缺少错误反馈。'),
 ('C,R','动作反馈不一致、连打单调；前段取钥匙跑图过慢。'),
 ('E,C,A,P','预期机制推理解谜，却体验到说明书知识锁；战斗、特定区域视效和敌人问题。肯定前段探索和世界变化后的回访。'),
 ('C','不喜欢冲刺系统，只有一句但可定位机制。'),
 ('O,R,C,E','机制隐藏；重复回访路线冗长；中段转向三Boss收集；战斗迟钝。'),
 ('A','改键受限且连带影响菜单确认/取消。'),
 ('O,R,C','文字不明、地图难定位、需攻略、战斗生硬。'),
 ],
 'tunic-positive':[
 ('N','仅赞美。'),('N','以Zelda/FEZ作赞美比较，缺少具体理由。'),('N','总体喜欢所有方面。'),('N','仅赞美。'),
 ('P,V,B','肯定谜题、画面、Boss。'),
 ('P','20小时后理解早已看见的物体用途，产生连接线索的惊喜。'),
 ('P,D','喜欢收集说明书及其中提示；提到矿区难度突增和挫折。'),
 ('N','仅与Outer Wilds并列赞美。'),('N','总体体验超出预期，未具体展开。'),
 ('P,V','发现感强，音乐音效强化体验。'),
 ],
 'animal-well-negative':[
 ('N','仅称不尊重时间，没有具体机制。'),
 ('R,L,V','后期反复解同房谜题、捷径不足和失误重跑；主流程与氛围受肯定，完成压力使后期痛苦。'),
 ('R,O','回访时不知道去哪推进，死亡回上个电话存档点。'),
 ('E,O,R','期待FEZ式谜题，但常不能判断是否缺道具；回访烦。'),
 ('E','期待深度解谜，实际体验更接近复古平台跳跃。'),
 ('E,V','以为是动作平台，实际不喜欢解谜；按视频打完，认可音画和环境。'),
 ('E,R,L,A','认为基础谜题像钥匙锁；新能力未改善回访；逐房重复探查工具用途、奖励和故事不满足；缺改键。'),
 ('R,E,V','地图通行像工作，开关谜题重复；认为无战斗可弥补，回访慢。'),
 ('R,P,V','喜欢音画和工具谜题；困难/耗时部分反复跑回的成本让探索兴趣消退。'),
 ('R,O,P,V','喜欢工具谜题和美术；失误或不知做什么引起反复重走和重解。'),
 ('N','辱骂/称损坏，无可定位细节。'),
 ('E,O,L,C,V,D','偏离预期的类型；谜题从简单跳到需攻略；无故事、后期冗长、Boss平台段令人不满。'),
 ('A','因缺改键而指出手部操作障碍。'),
 ('D','开始难度合适，之后惩罚过强；没有具体机制。'),
 ('N','只有辱骂。'),
 ('R','检查点系统造成负担。'),
 ('E,P,V','喜欢前段探索解谜和氛围；对后续恐怖追逐转向不满。'),
 ('R,O','没有领会快速旅行教学，大量徒步重走；认为基本便利功能应明确教会。'),
 ('E','认为基础谜题直白或隐藏路径，真正挑战在发现工具能力；不认为体验达到期待。'),
 ],
 'animal-well-positive':[
 ('V','肯定精致、美感、无故障及价值。'),
 ('V,P,B','肯定音画沉浸、机制、紧凑操作和大量秘密。'),
 ('N','推荐但评分6/10，认为没有压倒性优秀，未给具体理由。'),
 ('N','唤起童年Metroid体验，未具体展开机制。'),
 ('Q','希望更早解救猫。'),('N','仅称最喜欢之一。'),('N','仅喜爱。'),
 ('F','资深玩家仍感到品类体验新鲜。'),
 ('P,V','喜欢谜题与层次更深的彩蛋；明确认为适合完成主义玩家。'),
 ('N','仅称最喜欢之一。'),
 ]}
rows=[]
for filename,annotations in manual.items():
 data=json.loads((root/f'{filename}.json').read_text())
 reviews=data['response']['reviews']
 assert len(reviews)==len(annotations)
 game='TUNIC' if filename.startswith('tunic') else 'ANIMAL WELL'
 app=553420 if game=='TUNIC' else 813230
 for idx,(r,(tags,note)) in enumerate(zip(reviews,annotations),1):
  rows.append({'sample':filename,'sample_index':idx,'recommendationid':r['recommendationid'],'recommended':r['voted_up'],'date_utc':datetime.datetime.fromtimestamp(r['timestamp_created'],datetime.timezone.utc).isoformat(),'playtime_at_review_hours':round(r['author'].get('playtime_at_review',0)/60,2),'helpful_votes':r['votes_up'],'tags':tags.split(','),'note_zh':note,'url':f"https://steamcommunity.com/profiles/{r['author']['steamid']}/recommended/{app}/"})
(root/'manual-coding.json').write_text(json.dumps({'method':'Single analyst, direct full-text reading, manual multi-label coding; no keyword classification. Labels are descriptive and overlapping. N indicates no actionable mechanism-specific reason; denominators retain every returned review.','codebook':codes,'reviews':rows},ensure_ascii=False,indent=2))
with (root/'manual-coding.tsv').open('w') as f:
 w=csv.DictWriter(f,fieldnames=list(rows[0]),delimiter='\t');w.writeheader()
 for r in rows:w.writerow({**r,'tags':','.join(r['tags'])})
for filename in manual:
 part=[r for r in rows if r['sample']==filename]
 count=collections.Counter(tag for r in part for tag in r['tags'])
 print(filename,len(part),dict(count))
