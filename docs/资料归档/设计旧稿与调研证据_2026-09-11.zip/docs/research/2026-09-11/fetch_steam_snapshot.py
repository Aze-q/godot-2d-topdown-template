"""Reproduce the public Steam review snapshot used in this design review."""
import concurrent.futures
import datetime
import json
from pathlib import Path
import urllib.parse
import urllib.request

ROOT = Path(__file__).parent / "steam_snapshot"
GAMES = {553420: "TUNIC", 813230: "ANIMAL WELL", 368340: "CrossCode",
         1585180: "Drova - Forsaken Kin", 753640: "Outer Wilds", 1621690: "Core Keeper"}


def fetch(job):
    appid, language, review_type, count = job
    params = dict(json=1, filter="recent", language=language,
                  review_type=review_type, purchase_type="steam", num_per_page=count,
                  filter_offtopic_activity=1, cursor="*")
    url = f"https://store.steampowered.com/appreviews/{appid}?" + urllib.parse.urlencode(params)
    with urllib.request.urlopen(url, timeout=45) as response:
        data = json.load(response)
    if data.get("success") != 1:
        raise RuntimeError(f"Steam request failed: {url}")
    result = dict(game=GAMES[appid], appid=appid, source_url=url,
                  fetched_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                  parameters=params, response=data)
    path = ROOT / f"{appid}_{language}_{review_type}.json"
    path.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    summary = data.get("query_summary", {})
    return dict(game=GAMES[appid], language=language, review_type=review_type,
                returned=len(data["reviews"]), **summary)


if __name__ == "__main__":
    ROOT.mkdir(parents=True, exist_ok=True)
    jobs = [(appid, lang, "all", 1) for appid in GAMES
            for lang in ("all", "english", "schinese")]
    jobs += [(appid, "schinese", kind, count) for appid in (368340, 1585180)
             for kind, count in (("negative", 10), ("positive", 5))]
    with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(fetch, jobs))
    (ROOT / "summary.json").write_text(json.dumps(results, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(results, ensure_ascii=False, indent=2))
