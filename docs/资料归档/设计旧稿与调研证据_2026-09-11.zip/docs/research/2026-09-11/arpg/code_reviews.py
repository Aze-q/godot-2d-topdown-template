"""Human-authored review coding; code only formats/joins labels and counts them.
No keyword or sentiment classification is performed. Read all 60 originals first.
"""
import pathlib,json,datetime,csv,collections
p=pathlib.Path(__file__).parent
codebook={
 'PB':'负面：机关谜题/地牢数量过多、过长或机械重复；不把仅称难计入',
 'PE':'负面：机关谜题或平台操作的严格时限/精准瞄准/执行失败重做',
 'PF':'负面：表达谜题挫败但未说明数量或操作机制',
 'TV':'负面：平台移动、视角/高度辨识或地图表达妨碍导航',
 'BT':'负面：重复跑同一路径、回头取物或空跑',
 'GN':'负面：任务条件或主线目标引导不清',
 'CE':'负面：战斗节奏、难度、命中、公平性、血量、深度或技能执行',
 'CP':'正面：具体肯定战斗、Boss或战斗操作',
 'SP':'正面：具体肯定剧情、角色、NPC或世界设定；允许同一评论兼有负面',
 'SN':'负面：剧情/角色/世界设定乏味、缺乏吸引力、推进慢或结尾不满意',
 'EP':'正面：明确肯定探索、世界发现或环境探索实验',
 'PP':'正面：明确肯定机关谜题或解决过程',
 'PACE':'负面：内容整体拖长、重复或后期变乏味；非泛泛说不好玩',
 'GRIND':'负面：材料/升级刷取或收集流程劳动',
 'REWARD':'负面：探索宝箱回报平庸',
 'POWER':'负面：装备/数值成长不足以改变体验',
 'BUILD_NEG':'负面：核心动作被技能树锁定或Build配置不可恢复',
 'BUILD_POS':'正面：明确肯定Build选择或元素切换改变打法',
 'DANGER':'负面：探索因埋伏、惊吓、高惩罚/一击死受挫',
 'CHORES':'负面：跑腿或支线流程乏味',
 'INVENTORY':'负面：整理物品/操作状态切换不便',
}
manual={
 'crosscode-negative':[
 ('PB CE TV','认可外观；反对过多过长机关地牢、血厚敌人与平台跳跃。'),
 ('PB PE CE SN','开局喜欢，后期大量限时谜题与手柄瞄准、敌人战斗和反转使其弃玩。'),
 ('PB PE CP SP','认可战斗和故事趣味，但精密机关数量与疲劳压过剧情吸引力；36小时弃玩，自述回忆不清。'),
 ('PB PE TV','高度不易分辨、像素精确站位、重复平台谜题导致停玩；无崩溃。'),
 ('PACE','前两区之后只是换元素外观而重复，第二次仍在第三区弃玩。'),
 ('GN SN SP CHORES','失忆主线有吸引力；世界和任务不佳；前置任务无提示、主线目标不显示导致乱走。'),
 ('CE GRIND','早期难闪攻击与悬殊决斗造成挫折，感到必须刷级做支线按规定方式玩。'),
 ('TV BT CE PACE','赞美像素美术音效对白主题；地图抽象、自动跳跃与高度误判后跨区域折返，使其厌倦；也认为战斗简单。'),
 ('PB CP SP','战斗操作、角色互动、NPC与音乐好；机关数量淹没体验，靠角色结局才坚持完成。'),
 ('PB PE','起初感兴趣；机关密集、时限/反应、失败惩罚且无进一步答案使其不满。'),
 ('CE TV BT GRIND','高血量敌人、刷级压力、快重生、重复战斗；高差路线跨区、地图粗略使探索如劳作。'),
 ('PB SP','喜欢剧情和伤害调节；第二地牢太长，机关破坏乐趣。'),
 ('CE TV SP','剧情曾驱动继续，但战斗和平台移动不合喜好，弃玩后在视频补故事。'),
 ('PB PACE SN GRIND','中后段连续三个地牢过长、剧情收束不满意；尤其讨厌刷材料。'),
 ('TV BT PB PE PACE CP CE SP SN','肯定Boss、技能树和后来剧情；高度辨识、多屏折返、反复且精准限时的谜题、较晚剧情钩子磨掉乐趣；决斗难且不能练习。'),
 ('PB PACE CE','认同概念和交易，但敌人与过长地牢使其疲惫。'),
 ('PACE PB TV BT CE REWARD SP CP PP','初始战斗/谜题有趣、故事吸引；微调重复、重复跳跃战斗后平庸宝箱造成填充感。'),
 ('TV BT PACE CP','喜欢Boss；为互斥岔路、收集或跳错重复两三分钟路线，高度辨识加剧乏味。'),
 ('TV SN CHORES SP','美术音乐和故事题材有吸引力；向导频繁打断、地图阴影与跑腿支线令人烦躁；文中成就百分比未经本研究验证。'),
 ('PB PE CE PACE CP','部分Boss有趣；反复机关和失败全重做、Boss无敌等待/阶段锁血消耗大招，让94小时体验疲倦。'),
 ],
 'crosscode-positive':[
 ('CP PE EP SP','虽推荐却不合自己：战斗流畅但刺激过强，精密瞄准与时限不适；认可复杂环境探索和细致MMO背景。'),
 ('CP SP','赞美美术战斗音乐剧情，称谜题难但未评价其好坏。'),
 ('CP SP PP','明确赞美剧情、战斗和谜题制作与满足感。'),
 ('PP','把它推荐给爱谜题的人，称为最佳解谜游戏之一。'),
 ('','仅一个句点，无实质内容。'),
 ('CP PP BUILD_POS EP SP','肯定环境平台、限时机关、Boss剧情；近战配置与冰形态防反、随时切换打法带来乐趣。'),
 ('CP CE TV PP SP','总体非常喜欢故事音乐美术与战斗谜题；敌人破防窗口和模糊自动跳跃削弱探索。'),
 ('PF','总体推荐，但用夸张笑话表达对反射角机关的挫败。'),
 ('','总体高度赞美，没有具体机制理由。'),
 ('CP SP PB TV PP GRIND','喜欢角色、情节、战斗及解题满足感；地牢机关过多、高差跳跃不清，存在少量可接受刷取。'),
 ],
 'drova-negative':[
 ('CE DANGER','探索不断遭遇隐藏敌人突袭和一击死，惩罚探索欲。'),
 ('SN CHORES','战斗仅尚可；任务对白平庸，对Gothic的联想和照搬不满意。'),
 ('CE BUILD_NEG SN','认为基础动作锁在技能树里，升级并未提供改变打法的选择；战斗和剧情选择浅。'),
 ('SN','1.8小时未感到剧情角色吸引力，玩法无聊。'),
 ('','战斗尚可，其他内容基本且不感兴趣；无法分辨具体设计问题。'),
 ('CE CP POWER SP','高等级怪较好玩；人类敌人资源规则不公平、装备数值成长感弱；剧情起来后支持其通关。'),
 ('','仅谐音笑话，无实质内容。'),
 ('CE SN INVENTORY CHORES','退款窗口内未被吸引；基础砍躲循环、物品整理、跑腿和模板化阵营对白，难以关心角色。'),
 ('DANGER','原始森林每个角落的跳吓令其不满。'),
 ('','明确因Body Type而差评，并称游戏目前有趣；无本研究机制议题的有效内容。'),
 ('CE SN','战斗无聊、故事不吸引，没特殊严重问题但不想继续。'),
 ('','仅称完全普通，没有机制理由。'),
 ('','泛泛贬低；自述4小时与记录0.73小时不一致，不据此推断。'),
 ('SN','故事困惑且零散，未预期魂类风格，没有动力继续；未具体说探索惩罚。'),
 ('SN CE PACE EP','肯定早期探索；后期命中与技能问题、基础对白和剧情让其觉得拖沓。'),
 ('BUILD_NEG','误选最终护甲后改变属性尝试补救，后来得知可换甲却不能洗属性，觉得60小时Build损坏。'),
 ('BT CE PACE','后期跑任务道具时空地图往返、快速旅行覆盖少；敌人血厚、AOE与Y轴命中不满。'),
 ('CE DANGER SP','高惩罚探索与多次失败阻碍进展；建议开局自定义探索难度，仍觉得故事有潜力。'),
 ('SN','对白写作和世界吸引力弱，缺语音，难保持兴趣。'),
 ('','泛泛说点击/闲逛与挫折，没有明确机制；不做主题推断。'),
 ],
 'drova-positive':[
 ('','仅总体称可爱且上瘾，无具体机制理由。'),
 ('CP EP','喜欢复杂世界及严厉战斗促使自己探索其他路线。'),
 ('CP SP','剧情吸引，战斗有挑战与回报，驱动持续游玩。'),
 ('SP','明确称故事很棒，并愿重玩。'),
 ('POWER CE','推荐但不喜欢不能靠正确决策或刷取变强碾压；武器差异相对敌人血量小，战斗一直重复舞步。'),
 ('EP SP','剧情良好，尤其不断奖励好奇、实验、离开主路；通关后希望带着知识重新探索。'),
 ('EP CP','世界有趣，享受战斗、搜刮和美术。'),
 ('SP','认为像2D Skyrim但故事更有趣。'),
 ('','称有趣且享受重玩，未交代具体机制。'),
 ('EP CP SP','肯定探索战斗世界剧情；危险但适合当前等级的路线清楚，挑战不过度阻塞寻找方向。'),
 ],
}
rows=[]
for group,annotations in manual.items():
 raw=json.loads((p/(group+'.json')).read_text())['reviews']
 assert len(raw)==len(annotations)
 app=368340 if group.startswith('crosscode') else 1585180
 for i,(r,(tags,note)) in enumerate(zip(raw,annotations),1):
  codes=tags.split()
  assert all(c in codebook for c in codes)
  rows.append({'sample_id':group+'-'+str(i),'game':group.split('-')[0],'stratum':group.split('-')[1],'index':i,'recommendationid':r['recommendationid'],'url':f'https://steamcommunity.com/profiles/{r["author"]["steamid"]}/recommended/{app}/','recommended':r['voted_up'],'created_at_utc':datetime.datetime.fromtimestamp(r['timestamp_created'],datetime.timezone.utc).isoformat(),'updated_at_utc':datetime.datetime.fromtimestamp(r['timestamp_updated'],datetime.timezone.utc).isoformat(),'playtime_at_review_hours':round(r['author'].get('playtime_at_review',0)/60,2),'total_playtime_hours_at_fetch':round(r['author']['playtime_forever']/60,2),'received_for_free':r['received_for_free'],'tags':codes,'relevant_substantive_content':bool(codes),'paraphrase_zh':note})
(p/'coded-reviews.json').write_text(json.dumps({'method':'Single-analyst human multi-label coding after reading all 60 reviews. No automatic keyword classification. Codes include both valences within either recommendation stratum.','codebook':codebook,'rows':rows},ensure_ascii=False,indent=2))
with (p/'coded-reviews.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader()
 for r in rows: writer.writerow({**r,'tags':' '.join(r['tags'])})
counts={}
for group in manual:
 subset=[r for r in rows if r['sample_id'].startswith(group+'-')]
 counts[group]={'N':len(subset),'relevant_substantive':sum(r['relevant_substantive_content'] for r in subset),'tags':dict(collections.Counter(t for r in subset for t in r['tags'])),'insufficient':[r['sample_id'] for r in subset if not r['relevant_substantive_content']]}
(p/'theme-counts.json').write_text(json.dumps(counts,ensure_ascii=False,indent=2))
print(json.dumps(counts,ensure_ascii=False,indent=2))
